# LC'S STALKERS — Forge 1.20.1

Port del addon de Bedrock **LC'S STALKERS** a Forge 1.20.1 (Forge 47.3.0).

> Este proyecto **no se pudo compilar ni probar** donde se escribió (sin acceso a los servidores de Forge/Gradle).
> El código está revisado a mano y su sintaxis es válida, pero la primera compilación puede mostrar algún error de API que haya que corregir.

## Requisitos
- **JDK 17** (obligatorio para 1.20.1).
- Internet para la primera compilación (Gradle descarga Forge y Minecraft).

## Compilar
Este proyecto no trae el *wrapper* de Gradle. Elige una opción:

1. **IntelliJ IDEA / Eclipse:** abre la carpeta como proyecto Gradle; él se encarga de todo.
2. **Con Gradle 8.1.1 instalado:**
   ```
   gradle wrapper --gradle-version 8.1.1
   ./gradlew build
   ```
   (en Windows: `gradlew.bat build`)

El mod queda en `build/libs/lcstalkers-1.0.0.jar`. Cópialo a la carpeta `mods` de tu instancia de Forge 1.20.1.

Para probar sin instalar: `./gradlew runClient`.

## Criaturas
Los huevos de aparición están en la pestaña de creativo **Huevos generadores**. También con `/summon lcstalkers:<id>`.

| Criatura | ID | Qué hace |
|---|---|---|
| Quadrupedal Stalker | `quadrupedal_stalker` | Quieto hasta que lo miras; cambia de textura, suena y te persigue. Tiembla (animación dontcry) mientras persigue. |
| Anguish | `anguish` | Igual que el Quadrupedal Stalker (mismo sonido al cambiar de textura). |
| Tormentor | `tormentor` | Aparece lejos (sonido una vez). Si lo miras, desaparece y aparece 3 bloques detrás de ti. |
| Bipedal Stalker | `bipedal_stalker` | Aparece lejos. Si lo miras, se hunde, vuelve a salir con la cabeza doblada y te persigue tambaleando hasta matarte (no expira). |
| Cursed Bipedal | `cursed_bipedal` | Te mira de lejos (sonido una vez). Si te acercas a 8 bloques, te mata. |
| Cursed Quadrupedal | `cursed_quadrupedal` | Igual que el Cursed Bipedal. |

**Límites:** cada criatura desaparece **20 segundos** después de aparecer, y nunca puede haber más de **2** del mod a la vez en una dimensión (si aparece una tercera, desaparece la más antigua). **Excepción:** el Bipedal Stalker mientras te persigue no expira ni lo quita ese límite; desaparece cuando te mata.

Todos tienen un hitbox de 1 × 2 bloques (el dibujo conserva su tamaño). Todos te matan si te acercas a **2.5 bloques** (los Cursed, a **8**). Los jugadores en espectador se salvan; en creativo no.
Todos se dibujan siempre de frente a ti.

## Dónde ajustar cosas
| Quieres cambiar | Archivo |
|---|---|
| Tiempo de vida (20 s) | `MAX_LIFE_TICKS` en `BaseStalker.java` (20 ticks = 1 s) |
| Máximo de criaturas a la vez (2) | `MAX_STALKERS` en `ForgeEvents.java` |
| Radio de muerte | `KILL_RADIUS` en `entity/*.java` |
| Velocidad, vida, daño | `BaseStalker.chaserAttributes()` / `staticAttributes()` |
| Qué tan preciso hay que mirar | `LOOK_DOT` en `BaseStalker.java` (más cerca de 1 = más preciso) |
| Espera del Tormentor entre saltos | `COOLDOWN_TICKS` en `TormentorEntity.java` |
| Tamaño del dibujo | `client/ClientSetup.java` (ancho × alto en bloques) |
| Probabilidad de aparición | `data/lcstalkers/forge/biome_modifier/stalker_spawns.json` (`weight`) |

## Diferencias con la versión de Bedrock
- Detectar la mirada ahora usa **línea de visión real**: una pared entre tú y la criatura impide que cuente como mirarla (en Bedrock no).
- Las criaturas se dibujan con un renderer propio (un cartel que siempre te mira), no con un modelo `.geo.json`.
- La aparición natural exige estar a más de 40 bloques de cualquier jugador, pero no hay límite máximo exacto (Bedrock: 40–64).
- El Tormentor tiene una espera real de 4 s entre saltos (la versión de Bedrock no tenía).

## La casa (estructura)
Estructura en `data/lcstalkers/structures/casa.nbt` (9 × 9 × 13, dos pisos). Se coloca con:
```
/place template lcstalkers:casa ~-4 ~-3 ~-13
```
(párate donde quieres la entrada; el frente queda hacia ti). Medidas y materiales estimados a partir de las fotos; sin probar en el juego.

La casa también aparece sola, una vez por mundo, 8 bloques al este y al sur del punto de aparición del mundo (se ajusta a la altura del terreno en ese punto).
