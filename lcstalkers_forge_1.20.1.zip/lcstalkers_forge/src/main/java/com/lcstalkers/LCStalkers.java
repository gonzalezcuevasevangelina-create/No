package com.lcstalkers;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * LC'S STALKERS - Forge 1.20.1 port of the Bedrock addon.
 */
@Mod(LCStalkers.MODID)
public class LCStalkers {
    public static final String MODID = "lcstalkers";

    public LCStalkers() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
    }
}
