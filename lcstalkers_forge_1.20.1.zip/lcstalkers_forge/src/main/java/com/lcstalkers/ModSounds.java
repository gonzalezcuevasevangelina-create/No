package com.lcstalkers;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, LCStalkers.MODID);

    /** Quadrupedal Stalker: plays when it starts chasing. */
    public static final RegistryObject<SoundEvent> STALKER_CRACK = register("stalker_crack");
    /** Tormentor: plays once when it spawns. */
    public static final RegistryObject<SoundEvent> TORMENTOR_APPEAR = register("tormentor_appear");
    /** Cursed Bipedal / Cursed Quadrupedal: plays once when they spawn. */
    public static final RegistryObject<SoundEvent> CURSED_STALKING = register("cursed_stalking");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(LCStalkers.MODID, name)));
    }
}
