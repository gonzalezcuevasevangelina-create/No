package com.lcstalkers.client;

import com.lcstalkers.LCStalkers;
import com.lcstalkers.ModEntities;
import com.lcstalkers.entity.BaseStalker;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LCStalkers.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(LCStalkers.MODID, "textures/entity/" + name + ".png");
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // sprite size in blocks (width x height) = the Bedrock plane size / 16

        // Quadrupedal Stalker: idle texture -> chase texture, dontcry shake while chasing
        event.<BaseStalker>registerEntityRenderer(ModEntities.QUADRUPEDAL_STALKER.get(), ctx -> new StalkerRenderer(ctx,
                4.0F, 4.0F, tex("quadrupedal_stalker"), tex("quadrupedal_stalker_chase"), true, false));

        // Anguish
        event.<BaseStalker>registerEntityRenderer(ModEntities.ANGUISH.get(), ctx -> new StalkerRenderer(ctx,
                2.5F, 5.0F, tex("anguish"), tex("anguish_chase"), true, false));

        // Tormentor: "looking at you" texture -> "behind you" texture
        event.<BaseStalker>registerEntityRenderer(ModEntities.TORMENTOR.get(), ctx -> new StalkerRenderer(ctx,
                4.0F, 4.0F, tex("tormentor"), tex("tormentor_behind"), false, false));

        // Bipedal Stalker: sinks when looked at, rises again with the bent-head texture and chases (shaking)
        event.<BaseStalker>registerEntityRenderer(ModEntities.BIPEDAL_STALKER.get(), BipedalRenderer::new);

        // Cursed ones: single texture
        event.<BaseStalker>registerEntityRenderer(ModEntities.CURSED_BIPEDAL.get(), ctx -> new StalkerRenderer(ctx,
                2.298F, 4.0F, tex("cursed_bipedal"), null, false, false));
        event.<BaseStalker>registerEntityRenderer(ModEntities.CURSED_QUADRUPEDAL.get(), ctx -> new StalkerRenderer(ctx,
                2.973F, 4.0F, tex("cursed_quadrupedal"), null, false, false));
    }
}
