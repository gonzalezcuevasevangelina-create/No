package com.lcstalkers.client;

import com.lcstalkers.LCStalkers;
import com.lcstalkers.entity.BaseStalker;
import com.lcstalkers.entity.BipedalStalkerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Renderer of the Bipedal Stalker (billboard sprite).
 * variant 0: standing texture. variant 1: same texture sinking into the ground.
 * variant 2: chase texture (body + separate head), rising out of the ground, head bending, shaking.
 */
public class BipedalRenderer extends EntityRenderer<BaseStalker> {
    private static final ResourceLocation FAR = new ResourceLocation(LCStalkers.MODID, "textures/entity/bipedal_stalker.png");
    private static final ResourceLocation CHASE = new ResourceLocation(LCStalkers.MODID, "textures/entity/bipedal_stalker_chase.png");

    private static final float SHAKE = 0.512F / 16.0F;

    // standing sprite: 1.875 x 5 blocks
    private static final float FAR_W = 1.875F;
    private static final float FAR_H = 5.0F;

    // chase texture is 714 x 992: body at the left (602 px wide), head at the right (x 606..714, y 0..126)
    private static final float CHASE_W = 3.0F;
    private static final float CHASE_H = 5.0F;
    private static final float BODY_U1 = 602.0F / 714.0F;
    private static final float HEAD_U0 = 606.0F / 714.0F;
    private static final float HEAD_V1 = 126.0F / 992.0F;
    // head quad and pivot, from the Bedrock geometry (model units / 16)
    private static final float HEAD_X0 = -3.189F / 16.0F;
    private static final float HEAD_Y0 = 69.839F / 16.0F;
    private static final float HEAD_W = 8.611F / 16.0F;
    private static final float HEAD_H = 10.161F / 16.0F;
    private static final float PIVOT_X = 1.116F / 16.0F;
    private static final float PIVOT_Y = 74.919F / 16.0F;

    public BipedalRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public ResourceLocation getTextureLocation(BaseStalker entity) {
        return entity.getVariant() == BipedalStalkerEntity.VARIANT_CHASING ? CHASE : FAR;
    }

    @Override
    public void render(BaseStalker entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();

        Vec3 camera = this.entityRenderDispatcher.camera.getPosition();
        double dx = camera.x - Mth.lerp(partialTick, entity.xo, entity.getX());
        double dz = camera.z - Mth.lerp(partialTick, entity.zo, entity.getZ());
        poseStack.mulPose(Axis.YP.rotation((float) Math.atan2(dx, dz)));

        int variant = entity.getVariant();
        int ticks = entity.getSinkTicks();
        float seconds = Math.max(0, ticks - 1 + partialTick) / 20.0F;

        if (variant == BipedalStalkerEntity.VARIANT_CHASING) {
            float offsetX = ((System.currentTimeMillis() / 15L) % 2L == 0L ? -SHAKE : SHAKE);
            poseStack.translate(offsetX, riseOffset(seconds), 0.0D);
            VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(CHASE));
            quad(poseStack, consumer, -CHASE_W / 2.0F, 0.0F, CHASE_W / 2.0F, CHASE_H, 0.0F, 0.0F, BODY_U1, 1.0F, 0.0F, packedLight);

            // head: rotate around its pivot, drawn a hair in front of the body
            poseStack.pushPose();
            poseStack.translate(PIVOT_X, PIVOT_Y, 0.002D);
            poseStack.mulPose(Axis.ZP.rotationDegrees(headAngle(seconds)));
            poseStack.translate(-PIVOT_X, -PIVOT_Y, 0.0D);
            quad(poseStack, consumer, HEAD_X0, HEAD_Y0, HEAD_X0 + HEAD_W, HEAD_Y0 + HEAD_H, HEAD_U0, 0.0F, 1.0F, HEAD_V1, 0.0F, packedLight);
            poseStack.popPose();
        } else {
            float offsetX = 0.0F;
            float offsetY = 0.0F;
            if (variant == BipedalStalkerEntity.VARIANT_SINKING) {
                offsetY = sinkOffset(seconds);
                offsetX = (seconds < 0.3F ? 0.4F * (seconds / 0.3F) : -0.4F) / 16.0F;
            }
            poseStack.translate(offsetX, offsetY, 0.0D);
            VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(FAR));
            quad(poseStack, consumer, -FAR_W / 2.0F, 0.0F, FAR_W / 2.0F, FAR_H, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, packedLight);
        }

        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    /** Bedrock sink keyframes (model units): 0 -> -2 (0.3 s) -> -10 (0.6 s) -> -86 (1.5 s). */
    private static float sinkOffset(float t) {
        if (t <= 0.0F) {
            return 0.0F;
        } else if (t < 0.3F) {
            return Mth.lerp(t / 0.3F, 0.0F, -2.0F) / 16.0F;
        } else if (t < 0.6F) {
            return Mth.lerp((t - 0.3F) / 0.3F, -2.0F, -10.0F) / 16.0F;
        } else if (t < 1.5F) {
            return Mth.lerp((t - 0.6F) / 0.9F, -10.0F, -86.0F) / 16.0F;
        }
        return -86.0F / 16.0F;
    }

    /** Bedrock rise keyframes (model units): -86 -> -30 (0.9 s) -> 0 (1.2 s). */
    private static float riseOffset(float t) {
        if (t < 0.9F) {
            return Mth.lerp(t / 0.9F, -86.0F, -30.0F) / 16.0F;
        } else if (t < 1.2F) {
            return Mth.lerp((t - 0.9F) / 0.3F, -30.0F, 0.0F) / 16.0F;
        }
        return 0.0F;
    }

    /** Head bend (degrees, counter-clockwise as seen by the player): 0 until 1.2 s, then 100 deg by 1.8 s. */
    private static float headAngle(float t) {
        if (t <= 1.2F) {
            return 0.0F;
        } else if (t < 1.4F) {
            return Mth.lerp((t - 1.2F) / 0.2F, 0.0F, 35.0F);
        } else if (t < 1.55F) {
            return Mth.lerp((t - 1.4F) / 0.15F, 35.0F, 70.0F);
        } else if (t < 1.8F) {
            return Mth.lerp((t - 1.55F) / 0.25F, 70.0F, 100.0F);
        }
        return 100.0F;
    }

    private static void quad(PoseStack poseStack, VertexConsumer consumer, float x0, float y0, float x1, float y1,
                             float u0, float v0, float u1, float v1, float z, int light) {
        PoseStack.Pose pose = poseStack.last();
        vertex(consumer, pose, x0, y0, z, u0, v1, light);
        vertex(consumer, pose, x1, y0, z, u1, v1, light);
        vertex(consumer, pose, x1, y1, z, u1, v0, light);
        vertex(consumer, pose, x0, y1, z, u0, v0, light);
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                               float u, float v, int light) {
        consumer.vertex(pose.pose(), x, y, z)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(pose.normal(), 0.0F, 0.0F, 1.0F)
                .endVertex();
    }
}
