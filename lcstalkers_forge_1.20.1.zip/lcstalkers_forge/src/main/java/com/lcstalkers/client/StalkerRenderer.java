package com.lcstalkers.client;

import javax.annotation.Nullable;

import com.lcstalkers.entity.BaseStalker;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Draws a single-sided sprite that always turns (around the vertical axis) toward the camera, so the
 * stalker always "looks at you". Same idea as the billboard bone of the Bedrock addon.
 */
public class StalkerRenderer extends EntityRenderer<BaseStalker> {
    /** Bedrock dontcry shake: +-0.512 model units = 0.032 blocks, flipping every ~15 ms. */
    private static final float SHAKE = 0.512F / 16.0F;

    private final float width;
    private final float height;
    private final ResourceLocation idleTexture;
    @Nullable
    private final ResourceLocation activeTexture;
    private final boolean shakeWhenActive;
    private final boolean sinks;

    public StalkerRenderer(EntityRendererProvider.Context context, float width, float height,
                           ResourceLocation idleTexture, @Nullable ResourceLocation activeTexture,
                           boolean shakeWhenActive, boolean sinks) {
        super(context);
        this.width = width;
        this.height = height;
        this.idleTexture = idleTexture;
        this.activeTexture = activeTexture;
        this.shakeWhenActive = shakeWhenActive;
        this.sinks = sinks;
        this.shadowRadius = 0.0F;
    }

    @Override
    public ResourceLocation getTextureLocation(BaseStalker entity) {
        return (entity.isActive() && this.activeTexture != null) ? this.activeTexture : this.idleTexture;
    }

    @Override
    public void render(BaseStalker entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();

        // Turn the sprite (front = +Z) toward the camera, keeping it upright.
        Vec3 camera = this.entityRenderDispatcher.camera.getPosition();
        double dx = camera.x - Mth.lerp(partialTick, entity.xo, entity.getX());
        double dz = camera.z - Mth.lerp(partialTick, entity.zo, entity.getZ());
        poseStack.mulPose(Axis.YP.rotation((float) Math.atan2(dx, dz)));

        float offsetX = 0.0F;
        float offsetY = 0.0F;

        if (this.shakeWhenActive && entity.isActive()) {
            offsetX = ((System.currentTimeMillis() / 15L) % 2L == 0L ? -SHAKE : SHAKE);
        }

        int sink = entity.getSinkTicks();
        if (this.sinks && sink > 0) {
            float seconds = (sink - 1 + partialTick) / 20.0F;
            offsetY = sinkOffset(seconds);
            offsetX = (seconds < 0.3F ? 0.4F * (seconds / 0.3F) : -0.4F) / 16.0F; // small sway
        }

        poseStack.translate(offsetX, offsetY, 0.0D);
        drawSprite(poseStack, buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity))), packedLight);
        poseStack.popPose();

        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    /** Bedrock sink keyframes (in model units): 0 -> -2 (0.3 s) -> -10 (0.6 s) -> -86 (1.5 s). */
    private static float sinkOffset(float t) {
        if (t <= 0.0F) {
            return 0.0F;
        } else if (t < 0.3F) {
            return Mth.lerp(t / 0.3F, 0.0F, -2.0F) / 16.0F;
        } else if (t < 0.6F) {
            return Mth.lerp((t - 0.3F) / 0.3F, -2.0F, -10.0F) / 16.0F;
        } else if (t < 1.5F) {
            return Mth.lerp((t - 0.6F) / 0.9F, -10.0F, -86.0F) / 16.0F;
        }
        return -86.0F / 16.0F;
    }

    private void drawSprite(PoseStack poseStack, VertexConsumer consumer, int light) {
        PoseStack.Pose pose = poseStack.last();
        float half = this.width / 2.0F;
        vertex(consumer, pose, -half, 0.0F, 0.0F, 1.0F, light);          // bottom left
        vertex(consumer, pose, half, 0.0F, 1.0F, 1.0F, light);           // bottom right
        vertex(consumer, pose, half, this.height, 1.0F, 0.0F, light);    // top right
        vertex(consumer, pose, -half, this.height, 0.0F, 0.0F, light);   // top left
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y,
                               float u, float v, int light) {
        consumer.vertex(pose.pose(), x, y, 0.0F)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(pose.normal(), 0.0F, 0.0F, 1.0F)
                .endVertex();
    }
}
