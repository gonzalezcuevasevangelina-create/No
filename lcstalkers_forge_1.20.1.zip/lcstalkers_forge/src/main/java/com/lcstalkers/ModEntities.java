package com.lcstalkers;

import com.lcstalkers.entity.BaseStalker;
import com.lcstalkers.entity.BipedalStalkerEntity;
import com.lcstalkers.entity.ChasingStalker;
import com.lcstalkers.entity.CursedEntity;
import com.lcstalkers.entity.TormentorEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, LCStalkers.MODID);

    // Hitboxes are 1 x 2 blocks for every entity; the drawn sprite size is set in ClientSetup.
    public static final RegistryObject<EntityType<ChasingStalker>> QUADRUPEDAL_STALKER =
            register("quadrupedal_stalker",
                    (type, level) -> new ChasingStalker(type, level, ModSounds.STALKER_CRACK), 1.0F, 2.0F);

    public static final RegistryObject<EntityType<ChasingStalker>> ANGUISH =
            register("anguish",
                    (type, level) -> new ChasingStalker(type, level, ModSounds.STALKER_CRACK), 1.0F, 2.0F);

    public static final RegistryObject<EntityType<TormentorEntity>> TORMENTOR =
            register("tormentor", TormentorEntity::new, 1.0F, 2.0F);

    public static final RegistryObject<EntityType<BipedalStalkerEntity>> BIPEDAL_STALKER =
            register("bipedal_stalker", BipedalStalkerEntity::new, 1.0F, 2.0F);

    public static final RegistryObject<EntityType<CursedEntity>> CURSED_BIPEDAL =
            register("cursed_bipedal", CursedEntity::new, 1.0F, 2.0F);

    public static final RegistryObject<EntityType<CursedEntity>> CURSED_QUADRUPEDAL =
            register("cursed_quadrupedal", CursedEntity::new, 1.0F, 2.0F);

    private static <T extends BaseStalker> RegistryObject<EntityType<T>> register(
            String name, EntityType.EntityFactory<T> factory, float width, float height) {
        return ENTITIES.register(name, () -> EntityType.Builder.of(factory, MobCategory.MONSTER)
                .sized(width, height)
                .clientTrackingRange(10)
                .build(new ResourceLocation(LCStalkers.MODID, name).toString()));
    }
}
