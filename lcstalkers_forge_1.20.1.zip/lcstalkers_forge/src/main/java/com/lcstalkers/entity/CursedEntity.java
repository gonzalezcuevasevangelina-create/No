package com.lcstalkers.entity;

import javax.annotation.Nullable;

import com.lcstalkers.ModSounds;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/**
 * Cursed Bipedal / Cursed Quadrupedal: stand far away watching you (the renderer always faces them
 * toward the player). If you come within 8 blocks, they kill you. Sound plays once when they spawn.
 */
public class CursedEntity extends BaseStalker {
    private static final double KILL_RADIUS = 8.0D;

    public CursedEntity(EntityType<? extends CursedEntity> type, Level level) {
        super(type, level);
    }

    @Nullable
    @Override
    protected SoundEvent getSpawnSound() {
        return ModSounds.CURSED_STALKING.get();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void serverTick() {
        killPlayersWithin(KILL_RADIUS);
    }
}
