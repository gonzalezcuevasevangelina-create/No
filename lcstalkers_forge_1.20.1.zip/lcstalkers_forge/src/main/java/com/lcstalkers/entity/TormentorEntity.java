package com.lcstalkers.entity;

import javax.annotation.Nullable;

import com.lcstalkers.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Tormentor: appears far away (sound once), and every time a player looks at it, it vanishes and
 * reappears 3 blocks behind that player. Kills players within 2.5 blocks.
 */
public class TormentorEntity extends BaseStalker {
    private static final double KILL_RADIUS = 2.5D;
    private static final double BEHIND_DISTANCE = 3.0D;
    /** Ticks between teleports (4 s), so it does not hop every tick. */
    private static final int COOLDOWN_TICKS = 80;

    private int cooldown;

    public TormentorEntity(EntityType<? extends TormentorEntity> type, Level level) {
        super(type, level);
    }

    @Nullable
    @Override
    protected SoundEvent getSpawnSound() {
        return ModSounds.TORMENTOR_APPEAR.get();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void serverTick() {
        killPlayersWithin(KILL_RADIUS);
        if (this.cooldown > 0) {
            this.cooldown--;
            return;
        }
        ServerPlayer looker = findLookingPlayer();
        if (looker != null && teleportBehind(looker)) {
            setVariant(1); // "behind you" texture
            this.cooldown = COOLDOWN_TICKS;
        }
    }

    /** Moves behind the player (opposite to where they look), trying up to 3 blocks higher if blocked. */
    private boolean teleportBehind(ServerPlayer player) {
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0D, look.z);
        flat = flat.lengthSqr() < 1.0E-4D ? new Vec3(0.0D, 0.0D, 1.0D) : flat.normalize();
        double x = player.getX() - flat.x * BEHIND_DISTANCE;
        double z = player.getZ() - flat.z * BEHIND_DISTANCE;
        for (int dy = 0; dy <= 3; dy++) {
            double y = player.getY() + dy;
            AABB box = this.getType().getDimensions().makeBoundingBox(x, y, z);
            if (this.level().noCollision(this, box)) {
                this.getNavigation().stop();
                this.moveTo(x, y, z, this.getYRot(), this.getXRot());
                return true;
            }
        }
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("TormentorCooldown", this.cooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.cooldown = tag.getInt("TormentorCooldown");
    }
}
