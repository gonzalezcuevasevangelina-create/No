package com.lcstalkers.entity;

import com.lcstalkers.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Bipedal Stalker. variant 0 = stands far away, 1 = sinking (it was looked at), 2 = chasing.
 * After sinking (1.6 s) it rises again in the same spot, its head bends, and it chases (shaking)
 * until it kills a player. While chasing it never expires and is not removed by the 20 s / max-2 rules.
 */
public class BipedalStalkerEntity extends BaseStalker {
    private static final double KILL_RADIUS = 2.5D;
    /** 1.6 s, as in the Bedrock timer. */
    public static final int SINK_DURATION_TICKS = 32;
    public static final int VARIANT_SINKING = 1;
    public static final int VARIANT_CHASING = 2;

    public BipedalStalkerEntity(EntityType<? extends BipedalStalkerEntity> type, Level level) {
        super(type, level);
    }

    public boolean isChasing() {
        return getVariant() == VARIANT_CHASING;
    }

    @Override
    protected boolean hasLifeLimit() {
        return !isChasing();
    }

    @Override
    public boolean isPushable() {
        return isChasing();
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new ChaseMeleeGoal(this));
        this.targetSelector.addGoal(1, new ChaseHurtByGoal(this));
        this.targetSelector.addGoal(2, new ChaseTargetGoal(this));
    }

    @Override
    protected void serverTick() {
        int ticks = getSinkTicks();

        if (isChasing()) {
            if (ticks < 1000) {
                setSinkTicks(ticks + 1); // drives the rise / head-bend animation on the client
            }
            if (this.level() instanceof ServerLevel serverLevel) {
                boolean kills = false;
                for (ServerPlayer player : serverLevel.players()) {
                    if (!player.isSpectator() && player.isAlive() && player.distanceToSqr(this) <= KILL_RADIUS * KILL_RADIUS) {
                        kills = true;
                        break;
                    }
                }
                if (kills) {
                    killPlayersWithin(KILL_RADIUS);
                    this.discard(); // it disappears once it has killed
                }
            }
            return;
        }

        if (ticks > 0) { // sinking
            if (ticks >= SINK_DURATION_TICKS) {
                startChasing();
            } else {
                setSinkTicks(ticks + 1);
            }
            return; // cannot kill while sinking
        }

        killPlayersWithin(KILL_RADIUS);
        if (findLookingPlayer() != null) {
            setVariant(VARIANT_SINKING);
            setSinkTicks(1);
        }
    }

    private void startChasing() {
        setVariant(VARIANT_CHASING);
        setSinkTicks(1); // from now on counts the rise animation
        setPersistenceRequired();
        Player target = this.level().getNearestPlayer(this, 64.0D);
        if (target != null && !target.isSpectator()) {
            setTarget(target);
        }
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.STALKER_CRACK.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
    }

    // ---- goals that only run while chasing

    private static class ChaseMeleeGoal extends MeleeAttackGoal {
        private final BipedalStalkerEntity stalker;

        ChaseMeleeGoal(BipedalStalkerEntity stalker) {
            super(stalker, 1.0D, true);
            this.stalker = stalker;
        }

        @Override
        public boolean canUse() {
            return this.stalker.isChasing() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return this.stalker.isChasing() && super.canContinueToUse();
        }
    }

    private static class ChaseHurtByGoal extends HurtByTargetGoal {
        private final BipedalStalkerEntity stalker;

        ChaseHurtByGoal(BipedalStalkerEntity stalker) {
            super(stalker);
            this.stalker = stalker;
        }

        @Override
        public boolean canUse() {
            return this.stalker.isChasing() && super.canUse();
        }
    }

    private static class ChaseTargetGoal extends NearestAttackableTargetGoal<Player> {
        private final BipedalStalkerEntity stalker;

        ChaseTargetGoal(BipedalStalkerEntity stalker) {
            super(stalker, Player.class, 10, false, false, null);
            this.stalker = stalker;
        }

        @Override
        public boolean canUse() {
            return this.stalker.isChasing() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return this.stalker.isChasing() && super.canContinueToUse();
        }
    }
}
