package com.lcstalkers.entity;

import java.util.function.Supplier;

import javax.annotation.Nullable;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Quadrupedal Stalker and Anguish: stand still until a player looks at them, then switch texture
 * (and optionally play a sound) and chase that player. Kills players that get within 2.5 blocks.
 */
public class ChasingStalker extends BaseStalker {
    private static final double KILL_RADIUS = 2.5D;

    @Nullable
    private final Supplier<SoundEvent> activationSound;

    public ChasingStalker(EntityType<? extends ChasingStalker> type, Level level) {
        this(type, level, null);
    }

    public ChasingStalker(EntityType<? extends ChasingStalker> type, Level level,
                          @Nullable Supplier<SoundEvent> activationSound) {
        super(type, level);
        this.activationSound = activationSound;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new ActiveMeleeGoal(this));
        this.targetSelector.addGoal(1, new ActiveHurtByGoal(this));
        this.targetSelector.addGoal(2, new ActiveTargetGoal(this));
    }

    @Override
    protected void serverTick() {
        killPlayersWithin(KILL_RADIUS);
        if (!isActive()) {
            Player looker = findLookingPlayer();
            if (looker != null) {
                activate(looker);
            }
        }
    }

    private void activate(Player player) {
        setVariant(1);
        setTarget(player);
        if (this.activationSound != null) {
            this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                    this.activationSound.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    // ---- goals that only run once the stalker has been looked at

    private static class ActiveMeleeGoal extends MeleeAttackGoal {
        private final ChasingStalker stalker;

        ActiveMeleeGoal(ChasingStalker stalker) {
            super(stalker, 1.0D, true);
            this.stalker = stalker;
        }

        @Override
        public boolean canUse() {
            return this.stalker.isActive() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return this.stalker.isActive() && super.canContinueToUse();
        }
    }

    private static class ActiveHurtByGoal extends HurtByTargetGoal {
        private final ChasingStalker stalker;

        ActiveHurtByGoal(ChasingStalker stalker) {
            super(stalker);
            this.stalker = stalker;
        }

        @Override
        public boolean canUse() {
            return this.stalker.isActive() && super.canUse();
        }
    }

    private static class ActiveTargetGoal extends NearestAttackableTargetGoal<Player> {
        private final ChasingStalker stalker;

        ActiveTargetGoal(ChasingStalker stalker) {
            super(stalker, Player.class, 10, false, false, null);
            this.stalker = stalker;
        }

        @Override
        public boolean canUse() {
            return this.stalker.isActive() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return this.stalker.isActive() && super.canContinueToUse();
        }
    }
}
