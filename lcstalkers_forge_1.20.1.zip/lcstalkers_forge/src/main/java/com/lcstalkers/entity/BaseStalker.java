package com.lcstalkers.entity;

import javax.annotation.Nullable;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;

/**
 * Shared behaviour of every stalker: a synced "variant" (0 = idle texture, 1 = active texture),
 * a synced sink counter (used by the Bipedal Stalker), "is a player looking at me" detection,
 * and the proximity kill.
 */
public abstract class BaseStalker extends Monster {
    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(BaseStalker.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SINK =
            SynchedEntityData.defineId(BaseStalker.class, EntityDataSerializers.INT);

    /** How far away a player can be and still "look at" a stalker (Bedrock: search_radius 64). */
    protected static final double LOOK_RANGE = 64.0D;
    /** cos(angle) of the gaze cone: ~20 degrees around the centre of the body. */
    protected static final double LOOK_DOT = 0.94D;
    /** Every stalker vanishes this many ticks after it appeared (20 s). */
    public static final int MAX_LIFE_TICKS = 20 * 20;

    /** Ticks lived so far (saved, so reloading the world does not reset the 20 s). */
    private int lifeTicks;

    protected BaseStalker(EntityType<? extends BaseStalker> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    // ------------------------------------------------------------------ attributes

    /** Stalkers that never move on their own. */
    public static AttributeSupplier.Builder staticAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    /** Stalkers that chase once they have been looked at. */
    public static AttributeSupplier.Builder chaserAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.42D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D);
    }

    // ------------------------------------------------------------------ synced state

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_VARIANT, 0);
        this.entityData.define(DATA_SINK, 0);
    }

    public int getVariant() {
        return this.entityData.get(DATA_VARIANT);
    }

    protected void setVariant(int variant) {
        this.entityData.set(DATA_VARIANT, variant);
    }

    public boolean isActive() {
        return getVariant() == 1;
    }

    /** Ticks since the Bipedal Stalker started sinking (0 = not sinking). */
    public int getSinkTicks() {
        return this.entityData.get(DATA_SINK);
    }

    protected void setSinkTicks(int ticks) {
        this.entityData.set(DATA_SINK, ticks);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("StalkerVariant", getVariant());
        tag.putInt("StalkerSink", getSinkTicks());
        tag.putInt("StalkerLife", this.lifeTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("StalkerVariant"));
        setSinkTicks(tag.getInt("StalkerSink"));
        this.lifeTicks = tag.getInt("StalkerLife");
    }

    /** How long this stalker has existed, in ticks (used to pick the oldest one to remove). */
    public int getLifeTicks() {
        return this.lifeTicks;
    }

    // ------------------------------------------------------------------ ticking

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            if (++this.lifeTicks >= MAX_LIFE_TICKS && hasLifeLimit()) {
                this.discard(); // 20 seconds are up
                return;
            }
            serverTick();
        }
    }

    protected abstract void serverTick();

    /** False for a stalker that must stay until it has killed (the chasing Bipedal Stalker). */
    protected boolean hasLifeLimit() {
        return true;
    }

    /** True while this stalker must not be removed by the "max 2 stalkers" rule. */
    public boolean isProtectedFromRemoval() {
        return !hasLifeLimit();
    }

    // ------------------------------------------------------------------ helpers

    /** Kills every non-spectator player within {@code radius} blocks of this entity. */
    protected void killPlayersWithin(double radius) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        double radiusSqr = radius * radius;
        for (ServerPlayer player : serverLevel.players()) {
            if (player.isSpectator() || !player.isAlive()) {
                continue;
            }
            if (player.distanceToSqr(this) <= radiusSqr) {
                player.hurt(serverLevel.damageSources().genericKill(), Float.MAX_VALUE);
            }
        }
    }

    /** First player (within LOOK_RANGE) whose gaze cone contains this entity and who has line of sight. */
    @Nullable
    protected ServerPlayer findLookingPlayer() {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return null;
        }
        for (ServerPlayer player : serverLevel.players()) {
            if (isSeenBy(player)) {
                return player;
            }
        }
        return null;
    }

    protected boolean isSeenBy(Player player) {
        if (player.isSpectator() || !player.isAlive()) {
            return false;
        }
        Vec3 toMe = this.getBoundingBox().getCenter().subtract(player.getEyePosition());
        double distance = toMe.length();
        if (distance > LOOK_RANGE || distance < 1.0E-3D) {
            return false;
        }
        double dot = player.getViewVector(1.0F).normalize().dot(toMe.scale(1.0D / distance));
        return dot > LOOK_DOT && player.hasLineOfSight(this);
    }

    // ------------------------------------------------------------------ spawning / despawning

    /** Sound played once when the entity is freshly spawned (null = none). */
    @Nullable
    protected SoundEvent getSpawnSound() {
        return null;
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData data,
                                        @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        SoundEvent sound = getSpawnSound();
        if (sound != null) {
            // volume 6 -> audible up to ~96 blocks, like the Bedrock "playsound ... 6"
            this.level().playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundSource.HOSTILE, 6.0F, 1.0F);
        }
        return result;
    }

    /** Only despawn when very far away (Bedrock: 64-128), never by the random despawn closer than that. */
    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return hasLifeLimit() && distanceSqr > 128.0D * 128.0D;
    }
}
