package com.lcstalkers;

import com.lcstalkers.entity.BaseStalker;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Mod-bus events shared by client and server. */
@Mod.EventBusSubscriber(modid = LCStalkers.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.QUADRUPEDAL_STALKER.get(), BaseStalker.chaserAttributes().build());
        event.put(ModEntities.ANGUISH.get(), BaseStalker.chaserAttributes().build());
        event.put(ModEntities.TORMENTOR.get(), BaseStalker.staticAttributes().build());
        event.put(ModEntities.BIPEDAL_STALKER.get(), BaseStalker.chaserAttributes().build());
        event.put(ModEntities.CURSED_BIPEDAL.get(), BaseStalker.staticAttributes().build());
        event.put(ModEntities.CURSED_QUADRUPEDAL.get(), BaseStalker.staticAttributes().build());
    }

    @SubscribeEvent
    public static void onSpawnPlacements(SpawnPlacementRegisterEvent event) {
        register(event, ModEntities.QUADRUPEDAL_STALKER.get());
        register(event, ModEntities.ANGUISH.get());
        register(event, ModEntities.TORMENTOR.get());
        register(event, ModEntities.BIPEDAL_STALKER.get());
        register(event, ModEntities.CURSED_BIPEDAL.get());
        register(event, ModEntities.CURSED_QUADRUPEDAL.get());
    }

    private static <T extends BaseStalker> void register(SpawnPlacementRegisterEvent event, EntityType<T> type) {
        event.register(type, SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                ModEvents::checkSpawn, SpawnPlacementRegisterEvent.Operation.OR);
    }

    /** Dark enough like any monster, and (natural spawns only) at least 40 blocks away from every player. */
    private static <T extends BaseStalker> boolean checkSpawn(EntityType<T> type, ServerLevelAccessor level,
                                                              MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (!Monster.checkMonsterSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        if (reason == MobSpawnType.NATURAL) {
            return level.getNearestPlayer(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, 40.0D, false) == null;
        }
        return true;
    }

    @SubscribeEvent
    public static void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            ModItems.ITEMS.getEntries().forEach(event::accept);
        }
    }
}
