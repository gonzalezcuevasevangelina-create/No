package com.lcstalkers;

import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LCStalkers.MODID);

    public static final RegistryObject<Item> QUADRUPEDAL_STALKER_EGG = ITEMS.register(
            "quadrupedal_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.QUADRUPEDAL_STALKER, 0x0D0D0D, 0xD8C3A0, new Item.Properties()));

    public static final RegistryObject<Item> ANGUISH_EGG = ITEMS.register(
            "anguish_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ANGUISH, 0x4A0A12, 0xB01A2A, new Item.Properties()));

    public static final RegistryObject<Item> TORMENTOR_EGG = ITEMS.register(
            "tormentor_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.TORMENTOR, 0x0A0A0A, 0xB9A07A, new Item.Properties()));

    public static final RegistryObject<Item> BIPEDAL_STALKER_EGG = ITEMS.register(
            "bipedal_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BIPEDAL_STALKER, 0x101010, 0xC9C9C9, new Item.Properties()));

    public static final RegistryObject<Item> CURSED_BIPEDAL_EGG = ITEMS.register(
            "cursed_bipedal_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.CURSED_BIPEDAL, 0x0C0C0C, 0x8A8466, new Item.Properties()));

    public static final RegistryObject<Item> CURSED_QUADRUPEDAL_EGG = ITEMS.register(
            "cursed_quadrupedal_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.CURSED_QUADRUPEDAL, 0x0C0C0C, 0xD4C4A0, new Item.Properties()));
}
