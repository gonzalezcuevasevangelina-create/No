package com.lcstalkers;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.lcstalkers.entity.BaseStalker;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Game-bus events (server side logic shared by every stalker). */
@Mod.EventBusSubscriber(modid = LCStalkers.MODID)
public class ForgeEvents {
    /** At most this many stalkers can exist in a dimension at once; the oldest ones vanish. */
    public static final int MAX_STALKERS = 2;

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level) || !(event.getEntity() instanceof BaseStalker newcomer)) {
            return;
        }
        List<BaseStalker> others = new ArrayList<>(level.getEntities(
                EntityTypeTest.forClass(BaseStalker.class),
                stalker -> stalker != newcomer && stalker.isAlive() && !stalker.isRemoved() && !stalker.isProtectedFromRemoval()));
        // Oldest first. Keep MAX_STALKERS - 1 of the existing ones so that, with the newcomer, there are MAX_STALKERS.
        others.sort(Comparator.comparingInt(BaseStalker::getLifeTicks).reversed());
        while (others.size() > MAX_STALKERS - 1) {
            others.remove(0).discard();
        }
    }

    /** Places the house once per world, 8 blocks east and south of the world spawn. */
    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        ServerLevel level = event.getServer().overworld();
        HouseData data = level.getDataStorage().computeIfAbsent(HouseData::load, HouseData::new, "lcstalkers_house");
        if (data.placed) {
            return;
        }
        data.placed = true;
        data.setDirty();
        BlockPos base = level.getSharedSpawnPos().offset(8, 0, 8);
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, base);
        BlockPos origin = top.offset(0, -3, 0);
        level.getStructureManager().get(new ResourceLocation(LCStalkers.MODID, "casa")).ifPresent(template ->
                template.placeInWorld(level, origin, origin, new StructurePlaceSettings(), level.random, 2));
    }
}
