package com.lcstalkers;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;

/** Remembers (per world) that the house has already been placed near the spawn. */
public class HouseData extends SavedData {
    public boolean placed;

    public static HouseData load(CompoundTag tag) {
        HouseData data = new HouseData();
        data.placed = tag.getBoolean("Placed");
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Placed", this.placed);
        return tag;
    }
}
